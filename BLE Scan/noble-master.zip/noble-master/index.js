var Noble = require('./lib/noble');

module.exports = new Noble();
