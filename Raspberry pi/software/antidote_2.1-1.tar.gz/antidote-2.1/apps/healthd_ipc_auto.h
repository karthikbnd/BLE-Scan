#ifndef HEALTHD_IPC_AUTO_
#define HEALTHD_IPC_AUTO_

#include "healthd_ipc.h"

void healthd_ipc_auto_init(healthd_ipc *ipc);

#endif

