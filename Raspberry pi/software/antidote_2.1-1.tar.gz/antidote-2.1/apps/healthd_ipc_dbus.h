#ifndef HEALTHD_IPC_DBUS_
#define HEALTHD_IPC_DBUS_

#include "healthd_ipc.h"

void healthd_ipc_dbus_init(healthd_ipc *ipc);

#endif
