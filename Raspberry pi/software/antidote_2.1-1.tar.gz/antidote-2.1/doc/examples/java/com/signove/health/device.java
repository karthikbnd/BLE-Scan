/*
 * Copyright (c) 2012 Signove Tecnologia S/A
 */

package com.signove.health;

import org.freedesktop.dbus.*;

@DBusInterfaceName("com.signove.health.device")
public interface device extends DBusInterface {
	// FIXME fill
}
